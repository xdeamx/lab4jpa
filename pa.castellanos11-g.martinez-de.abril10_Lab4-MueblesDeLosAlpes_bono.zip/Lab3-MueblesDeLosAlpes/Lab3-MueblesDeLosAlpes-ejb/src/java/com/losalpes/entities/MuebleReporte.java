/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.losalpes.entities;

/**
 *
 * @author xDEAMx
 */
public class MuebleReporte {
    
    private Long id;
    private String nombre;
    private Integer total;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
    
    
}
